package Domineering;


public abstract class Position {

}

