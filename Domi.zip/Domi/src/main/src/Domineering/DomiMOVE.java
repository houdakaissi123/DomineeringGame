package Domineering;//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//


public class DomineeringMove extends Move {
    public int row;
    public int col;

    public DomineeringMove(int row, int col) {
        this.row = row;
        this.col = col;
    }


}

