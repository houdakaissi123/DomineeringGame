import javax.swing.*;

public class GUI {
    private javax.swing.JPanel JPanel;
    private JPanel title;
    private JTextArea title1;
    private JPanel left;
    private JPanel right;
    private JButton b1Button;
    private JButton b2Button;
    private JButton b3Button;
    private JButton b4Button;
    private JButton b5Button;
    private JButton b6Button;
    private JButton b7Button;
    private JButton b8Button;
    private JButton b9Button;
}
