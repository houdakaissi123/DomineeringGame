
package Domineering;

public abstract class Move {

}

